/*
  الحايطي AI — دليل أدوات الذكاء الاصطناعي
  لتعديل بيانات أداة: غيّر السطر الخاص بها في TOOL_ROWS.
  تنسيق كل سطر: اسم الأداة | رقم التصنيف | الرابط الرسمي | الوصف | نوع الخطة
  أنواع الخطط: f = لديها خطة مجانية، x = مجانية، p = مدفوعة، v = راجع الخطط.
  ليس هذا الموقع وسيطًا تقنيًا لخدمات الأدوات الخارجية؛ الروابط تفتح مواقعها مباشرة.
*/
'use strict';
const CATEGORIES = [
  {id:'all',name:'جميع الأدوات',symbol:'✦'},
  {id:'chat',name:'المساعدات الذكية',symbol:'◎'},
  {id:'search',name:'البحث والمعرفة',symbol:'⌕'},
  {id:'image',name:'توليد الصور',symbol:'◈'},
  {id:'photo',name:'تحرير الصور',symbol:'▣'},
  {id:'video',name:'الفيديو والمونتاج',symbol:'▶'},
  {id:'avatar',name:'الأفاتار',symbol:'◉'},
  {id:'audio',name:'الصوت والموسيقى',symbol:'♫'},
  {id:'code',name:'البرمجة',symbol:'⌘'},
  {id:'build',name:'بناء المواقع',symbol:'▤'},
  {id:'writing',name:'الكتابة والمحتوى',symbol:'✎'},
  {id:'design',name:'التصميم والعروض',symbol:'◇'},
  {id:'autom',name:'الأتمتة والإنتاجية',symbol:'⚙'},
  {id:'education',name:'التعليم والدراسة',symbol:'▧'},
  {id:'translate',name:'الترجمة واللغات',symbol:'文'},
  {id:'threeD',name:'التصميم ثلاثي الأبعاد',symbol:'⬡'},
  {id:'marketing',name:'التسويق',symbol:'◬'},
  {id:'data',name:'البيانات والتحليل',symbol:'▥'},
  {id:'security',name:'الأمن السيبراني',symbol:'⬟'},
];
let tools = [];
let currentUser = null;
let csrfToken = '';
async function requestAPI(url,method='GET',data){
  const headers = {'Content-Type':'application/json'};
  if (method !== 'GET') headers['X-CSRF-Token'] = csrfToken;
  const response = await fetch(url,{method,headers,credentials:'same-origin', ...(data!==undefined?{body:JSON.stringify(data)}:{})});
  let result; try{result=await response.json()}catch{result={}}
  if(!response.ok) throw new Error(typeof result.detail==='string'?result.detail:'تعذّر الاتصال بالخادم');
  return result;
}
async function loadCatalog(){
  try{
    const result=await requestAPI('/api/tools');
    tools=result.tools;
    $('heroToolCount').textContent='+'+tools.length;
    $('catalogTotal').textContent=String(tools.length);
    render();
  }catch(e){$('resultCount').textContent='تعذر تحميل دليل الأدوات؛ تأكد من تشغيل الخادم.';console.error(e)}
}
async function updateAccount(){
  try{
    const result=await requestAPI('/api/auth/me');
    currentUser=result.user;
    csrfToken=result.csrf||'';
    if(currentUser){
      favs.clear();(result.favorites||[]).forEach(id=>favs.add(id));
      $('accountButton').textContent='◉ '+currentUser.name;
      const link=$('adminLink');if(link) link.hidden=currentUser.role!=='admin';const mobileLink=$('mobileAdminLink');if(mobileLink)mobileLink.hidden=currentUser.role!=='admin';
    } else {$('accountButton').textContent='حسابي ◉';const link=$('adminLink');if(link)link.hidden=true;const mobileLink=$('mobileAdminLink');if(mobileLink)mobileLink.hidden=true}
    render();
  }catch(e){console.error(e)}
}
function accountModal(){
  if(currentUser){
    openModal(`<span class="section-kicker">حسابك الشخصي</span><h2 class="modal-title" id="modalTitle">مرحباً ${esc(currentUser.name)}</h2><p class="modal-desc">البريد: ${esc(currentUser.email)}</p><div class="modal-actions">${currentUser.role==='admin'?'<a class="button primary-button" href="/admin">لوحة التحكم ⚙</a>':''}<button id="logoutBtn" type="button" class="button secondary-button">تسجيل الخروج</button></div>`);
    $('logoutBtn').onclick=async()=>{try{await requestAPI('/api/auth/logout','POST');currentUser=null;csrfToken='';favs.clear();closeModal();await updateAccount()}catch(err){toast(err.message)}};
  } else {
    openModal(`<span class="section-kicker">الحايطي AI</span><h2 class="modal-title" id="modalTitle">تسجيل الدخول</h2><div class="modal-actions"><button class="button secondary-button" id="switchRegister" type="button">إنشاء حساب جديد</button></div><form id="authForm" class="modal-form"><div id="nameField" hidden><label class="form-field">الاسم<input name="name" minlength="2" maxlength="80" autocomplete="name"></label></div><label class="form-field">البريد الإلكتروني<input name="email" type="email" required autocomplete="email"></label><label class="form-field">كلمة المرور<input name="password" type="password" minlength="12" required autocomplete="current-password"></label><p id="loginError" class="form-note" role="alert"></p><button class="button primary-button" type="submit" id="authSubmit">دخول</button></form><p class="form-note">كلمة المرور 12 رمزًا على الأقل. حساب المدير يُنشأ من إعدادات الخادم فقط.</p>`);
    let registration=false;
    $('switchRegister').onclick=()=>{registration=!registration;$('switchRegister').textContent=registration?'العودة إلى تسجيل الدخول':'إنشاء حساب جديد';$('nameField').hidden=!registration;$('authSubmit').textContent=registration?'إنشاء الحساب':'دخول';$('authForm').elements.name.required=registration};
    $('authForm').onsubmit=async e=>{e.preventDefault();const data=Object.fromEntries(new FormData(e.currentTarget));if(!registration) delete data.name;try{const r=await requestAPI(registration?'/api/auth/register':'/api/auth/login','POST',data);if(registration){$('loginError').textContent='تم إنشاء الحساب! يمكنك الآن تسجيل الدخول.';$('switchRegister').click()}else{csrfToken=r.csrf;closeModal();await updateAccount();toast('تم تسجيل الدخول بنجاح')}}catch(err){$('loginError').textContent=err.message}};
  }
}
const categoryMap = new Map(CATEGORIES.map(c=>[c.id,c]));
const $ = id=>document.getElementById(id);
const esc = s=>String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const getSaved = (key,def)=>{try{return JSON.parse(localStorage.getItem(key))??def}catch{return def}};
const save = (key,data)=>{try{localStorage.setItem(key,JSON.stringify(data))}catch{}};
const safeUrl = url=>{try{const u=new URL(url);return u.protocol==='https:'?u.href:'#'}catch{return '#'}};
const readablePlan = p=>p==='x'?'مجانية':p==='f'?'خطة مجانية':p==='p'?'مدفوعة':'راجع الخطط';
const favs = new Set(getSaved('alhayti-favorites',[]).filter(id=>Number.isInteger(id)));
const state={category:'all',query:'',onlyFree:false,favorites:false,sort:'featured',visible:24};
const palette=[['#6f49dd','#20a4b8'],['#e76586','#ab59f4'],['#277bc5','#22bdad'],['#aa7534','#dd4b77'],['#4b8f77','#2aa5bd'],['#8966b4','#718edc'],['#3084a4','#3763ad']];
let toastTimer,previousFocus=null;
function getPalette(id){return palette[(id*7+Math.floor(id/3))%palette.length]}
function logoText(name){return name.replace(/[^\p{L}\p{N}\s.]/gu,'').trim().split(/\s+/).slice(0,2).map(w=>w[0]).join('').toUpperCase().slice(0,2)||'AI'}
function logoStyle(tool){const [a,b]=getPalette(tool.id);return `--logo-a:${a};--logo-b:${b}`}
function faviconUrl(tool){try{return `https://www.google.com/s2/favicons?sz=64&domain_url=${encodeURIComponent(new URL(tool.url).origin)}`}catch{return ''}}
function hasFree(p){return p==='x'||p==='f'}
function filteredTools(){let items=tools.filter(t=>{
  if(state.category!=='all'&&t.category!==state.category)return false;
  if(state.favorites&&!favs.has(t.id))return false;
  if(state.onlyFree&&!hasFree(t.plan))return false;
  if(state.query){const text=[t.name,t.description,categoryMap.get(t.category).name,new URL(t.url).hostname].join(' ').toLocaleLowerCase();if(!text.includes(state.query))return false}
  return true;
});
if(state.sort==='az')items.sort((a,b)=>a.name.localeCompare(b.name,'ar'));
else if(state.sort==='za')items.sort((a,b)=>b.name.localeCompare(a.name,'ar'));
return items;
}
function renderCategories(){
  $('categoryList').innerHTML=CATEGORIES.map(cat=>`<button type="button" class="category-pill ${cat.id===state.category?'active':''}" data-category="${cat.id}" aria-pressed="${cat.id===state.category}"><span aria-hidden="true">${cat.symbol}</span>${cat.name}</button>`).join('');
}
function renderCard(tool){
  const saved=favs.has(tool.id), category=categoryMap.get(tool.category);
  return `<article class="tool-card" data-id="${tool.id}">
     <div class="tool-top"><span class="tool-logo real-logo" style="${logoStyle(tool)}" aria-hidden="true"><img src="/api/logos/${tool.id}" alt="" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><b style="display:none">${esc(logoText(tool.name))}</b></span><button class="favorite-tool ${saved?'saved':''}" data-action="fav" data-id="${tool.id}" aria-label="${saved?'إزالة':'إضافة'} ${esc(tool.name)} ${saved?'من':'إلى'} المفضلة" aria-pressed="${saved}">${saved?'♥':'♡'}</button></div>
     <h3 class="tool-name">${esc(tool.name)}</h3><p class="tool-description">${esc(tool.description)}</p>
     <div class="tool-bottom"><div class="tool-tags"><span class="tool-category">${esc(category.name)}</span><span class="tool-plan ${tool.plan==='v'?'varies':tool.plan==='p'?'paid':''}">${readablePlan(tool.plan)}</span></div><a class="tool-open" href="${safeUrl(tool.url)}" target="_blank" rel="noopener noreferrer" aria-label="زيارة ${esc(tool.name)}">استخدم ←</a></div>
     <div class="tool-more"><button type="button" class="tool-detail" data-action="detail" data-id="${tool.id}">عرض التفاصيل +</button><span class="tool-domain">${esc(new URL(tool.url).hostname.replace('www.',''))}</span></div>
   </article>`;
}
function render(){
  const items=filteredTools();
  $('toolsGrid').innerHTML=items.slice(0,state.visible).map(renderCard).join('');
  $('resultCount').textContent=`عرض ${Math.min(state.visible,items.length)} من ${items.length} أداة`;
  $('emptyState').hidden=items.length>0;
  $('loadMore').parentElement.hidden=state.visible>=items.length||items.length===0;
  $('favoriteCount').textContent=String(favs.size);
  $('favoritesButton').classList.toggle('active',state.favorites);
  $('favoritesButton').setAttribute('aria-pressed',String(state.favorites));
  $('favoritesButton').querySelector('span').textContent=state.favorites?'♥':'♡';
  renderCategories();
}
function resetFilters(){state.category='all';state.query='';state.onlyFree=false;state.favorites=false;state.sort='featured';state.visible=24;$('searchInput').value='';$('freeOnly').checked=false;$('sortSelect').value='featured';render()}
function toast(message){const el=$('toast');el.textContent=message;el.classList.add('show');clearTimeout(toastTimer);toastTimer=setTimeout(()=>el.classList.remove('show'),2600)}
function openModal(content){previousFocus=document.activeElement;$('modalContent').innerHTML=content;$('modalRoot').hidden=false;document.body.style.overflow='hidden';$('modalRoot').querySelector('.modal-close').focus()}
function closeModal(){$('modalRoot').hidden=true;document.body.style.overflow='';$('modalContent').innerHTML='';previousFocus?.focus?.()}
function detail(tool){const cat=categoryMap.get(tool.category);openModal(`<div class="modal-brand"><span class="tool-logo real-logo" style="${logoStyle(tool)}"><img src="/api/logos/${tool.id}" alt="" onerror="this.style.display='none';this.nextElementSibling.style.display='block'"><b style="display:none">${esc(logoText(tool.name))}</b></span><div><span class="section-kicker">معلومات الأداة</span><h2 class="modal-title" id="modalTitle">${esc(tool.name)}</h2></div></div><p class="modal-desc" style="margin-top:19px">${esc(tool.description)}</p><div class="modal-meta"><span>التصنيف: ${esc(cat.name)}</span><span>الخطة: ${readablePlan(tool.plan)}</span><span dir="ltr">${esc(new URL(tool.url).hostname)}</span></div><p class="form-note" style="margin-bottom:20px">تُقدَّم هذه الخدمة من شركة مستقلة. تحقّق من سياسة الخصوصية والاشتراك في موقعها.</p><div class="modal-actions"><a class="button primary-button" target="_blank" rel="noopener noreferrer" href="${safeUrl(tool.url)}">زيارة الموقع الرسمي ↗</a><button type="button" class="button secondary-button" id="shareTool">نسخ الرابط ⧉</button></div>`);
$('shareTool').addEventListener('click',()=>copyText(tool.url));
}
async function copyText(text){try{await navigator.clipboard.writeText(text);toast('تم نسخ النص بنجاح')}catch{const el=document.createElement('textarea');el.value=text;el.style.position='fixed';el.style.opacity='0';document.body.appendChild(el);el.select();const success=document.execCommand('copy');el.remove();toast(success?'تم نسخ النص':'حدّد النص وانسخه يدويًا')}}
function openSuggest(){openModal(`<span class="section-kicker">شارِك اقتراحك</span><h2 class="modal-title" id="modalTitle">اقترح أداة جديدة</h2><p class="modal-desc">أرسل اسم الأداة ورابطها للمطور عبر واتساب ليتم مراجعتها.</p><form id="suggestForm" class="modal-form"><label class="form-field">اسم الأداة <input name="name" required maxlength="75" placeholder="اسم الأداة" /></label><label class="form-field">رابط موقع الأداة <input name="url" required type="url" pattern="https?://.*" placeholder="https://example.com" /></label><label class="form-field">ماذا تقدّم؟ <textarea name="details" maxlength="500" placeholder="وصف مختصر (اختياري)"></textarea></label><button type="submit" class="button primary-button">إرسال الاقتراح عبر واتساب ↗</button><p class="form-note">عند الضغط سيُفتح واتساب برسالة جاهزة، ولن يُرسل شيء حتى تؤكد إرساله بنفسك.</p></form>`);
$('suggestForm').addEventListener('submit',e=>{e.preventDefault();const data=new FormData(e.currentTarget);const msg=`اقتراح أداة لمنصة الحايطي AI\nالاسم: ${data.get('name')}\nالرابط: ${data.get('url')}\nالوصف: ${data.get('details')||'لا يوجد'}`;window.open(`https://wa.me/967779922816?text=${encodeURIComponent(msg)}`,'_blank','noopener,noreferrer');toast('تم تجهيز الاقتراح في واتساب')});
}
function openUtility(type){
if(type==='prompt'){
 openModal(`<span class="section-kicker">أداة تعمل داخل المتصفح</span><h2 class="modal-title" id="modalTitle">✳ منشئ الأوامر الاحترافية</h2><p class="modal-desc">جهّز طلبًا واضحًا يمكن نسخه إلى ChatGPT أو أي مساعد آخر. هذه الأداة لا تتصل بنموذج AI.</p><form id="promptForm" class="modal-form"><label class="form-field">الدور المطلوب من المساعد <select name="role"><option>خبير في المجال</option><option>مدرّس متخصص</option><option>مصمم جرافيك محترف</option><option>مهندس برمجيات</option><option>متخصص تسويق</option><option>مستشار أمن سيبراني دفاعي</option></select></label><label class="form-field">ماذا تريد إنجازه؟ <textarea name="task" required placeholder="مثال: إعداد خطة تسويق شهرية لمتجر إلكتروني"></textarea></label><label class="form-field">لمن النتيجة؟ <input name="audience" placeholder="مثلًا: مبتدئون أو أصحاب مشاريع" /></label><label class="form-field">أسلوب الإجابة <select name="tone"><option>واضح واحترافي</option><option>مختصر ومباشر</option><option>تفصيلي وتعليمي</option><option>إبداعي وجذاب</option></select></label><label class="form-field">صيغة المخرجات <select name="format"><option>خطوات منظمة</option><option>جدول مرتب</option><option>نقاط موجزة</option><option>شرح مفصل مع أمثلة</option></select></label><button type="submit" class="button primary-button">أنشئ الأمر ✳</button></form><div id="promptResult" hidden><h3>النص الجاهز</h3><div id="promptOutput" class="text-output"></div><button type="button" id="copyPrompt" class="button secondary-button" style="margin-top:12px">نسخ الأمر ⧉</button></div>`);
 $('promptForm').addEventListener('submit',e=>{e.preventDefault();const d=new FormData(e.currentTarget);const output=`تصرّف بصفتك ${d.get('role')}.\n\nالمهمة: ${d.get('task')}.\nالفئة المستهدفة: ${d.get('audience')||'الجمهور العام'}.\nأسلوب الرد: ${d.get('tone')}.\nصيغة المخرجات: ${d.get('format')}.\n\nالتعليمات: قدّم محتوى دقيقًا وعمليًا باللغة العربية، مع مراعاة السياق والتسلسل المنطقي، واذكر الافتراضات المهمة وأي نقاط تحتاج إلى تحقق بدل اختلاق المعلومات.`;$('promptOutput').textContent=output;$('promptResult').hidden=false});
 $('copyPrompt').addEventListener('click',()=>copyText($('promptOutput').textContent));
}else if(type==='text'){
 openModal(`<span class="section-kicker">أداة تعمل داخل المتصفح</span><h2 class="modal-title" id="modalTitle">▤ محلل النصوص</h2><p class="modal-desc">اكتب النص أو الصقه لعرض الإحصاءات بشكل فوري. النص يبقى على جهازك.</p><label class="form-field">النص <textarea id="analysisInput" rows="8" placeholder="ضع النص هنا..."></textarea></label><div class="text-stats" style="margin-top:15px"><div><strong id="wordStat">0</strong><small>كلمة</small></div><div><strong id="charStat">0</strong><small>حرف مع الفراغات</small></div><div><strong id="sentenceStat">0</strong><small>جملة تقريبًا</small></div><div><strong id="readStat">0</strong><small>دقيقة قراءة</small></div></div><button type="button" class="button secondary-button" style="margin-top:18px" id="cleanWhitespace">تنظيف الفراغات الزائدة ✳</button>`);
 const calc=()=>{const t=$('analysisInput').value;const words=t.trim()?t.trim().split(/\s+/u).length:0;const sentence=t.trim()?t.split(/[.!؟?\n]+/u).filter(s=>s.trim()).length:0;$('wordStat').textContent=words;$('charStat').textContent=Array.from(t).length;$('sentenceStat').textContent=sentence;$('readStat').textContent=words?Math.max(1,Math.ceil(words/220)):0};$('analysisInput').addEventListener('input',calc);$('cleanWhitespace').addEventListener('click',()=>{$('analysisInput').value=$('analysisInput').value.replace(/[ \t]+/g,' ').replace(/\n{3,}/g,'\n\n').trim();calc();toast('تم تنظيف الفراغات')});
}else if(type==='json'){
 openModal(`<span class="section-kicker">أداة تعمل داخل المتصفح</span><h2 class="modal-title" id="modalTitle">{ } تنسيق JSON</h2><p class="modal-desc">تحقّق من تنسيق البيانات، ثم انسخ النسخة المنظمة. المعالجة محلية على جهازك.</p><label class="form-field">بيانات JSON <textarea id="jsonInput" rows="7" dir="ltr" placeholder='{"name":"AlHayti AI","tools":150}'></textarea></label><div class="modal-actions" style="margin:13px 0"><button type="button" class="button primary-button" id="formatJson">تحقق ونسّق</button><button type="button" class="button secondary-button" id="minifyJson">تصغير JSON</button></div><p id="jsonStatus" class="form-note" role="status"></p><div id="jsonResult" class="text-output" dir="ltr" style="text-align:left"></div><button type="button" class="button secondary-button" id="copyJson" style="margin-top:13px">نسخ النتيجة ⧉</button>`);
 const format=(pretty)=>{try{const obj=JSON.parse($('jsonInput').value);$('jsonResult').textContent=JSON.stringify(obj,null,pretty?2:0);$('jsonStatus').textContent='✓ JSON صالح';$('jsonStatus').style.color='var(--accent2)'}catch(err){$('jsonStatus').textContent='خطأ في الصيغة: '+err.message;$('jsonStatus').style.color='#ff929c';$('jsonResult').textContent=''}};$('formatJson').addEventListener('click',()=>format(true));$('minifyJson').addEventListener('click',()=>format(false));$('copyJson').addEventListener('click',()=>{$('jsonResult').textContent?copyText($('jsonResult').textContent):toast('لا توجد نتيجة لنسخها')});
}
}
function init(){
 $('heroToolCount').textContent='+'+tools.length;
 $('heroCategoryCount').textContent=String(CATEGORIES.length-1);
 $('catalogTotal').textContent=String(tools.length);
 $('year').textContent=new Date().getFullYear();
 const theme=getSaved('alhayti-theme','dark'),accent=getSaved('alhayti-accent','violet');
 if(['light','dark'].includes(theme))document.body.dataset.theme=theme;
 if(['violet','ocean','sunset','emerald'].includes(accent))document.body.dataset.accent=accent;
 render();loadCatalog();updateAccount();$('accountButton').addEventListener('click',accountModal);
 $('categoryList').addEventListener('click',e=>{const btn=e.target.closest('[data-category]');if(!btn)return;state.category=btn.dataset.category;state.visible=24;render()});
 $('toolsGrid').addEventListener('click',e=>{const btn=e.target.closest('[data-action]');if(!btn)return;const tool=tools.find(t=>t.id===Number(btn.dataset.id));if(!tool)return;if(btn.dataset.action==='fav'){favs.has(tool.id)?favs.delete(tool.id):favs.add(tool.id);save('alhayti-favorites',[...favs]);render();if(currentUser)requestAPI(`/api/favorites/${tool.id}`,favs.has(tool.id)?'POST':'DELETE').catch(err=>toast(err.message));toast(favs.has(tool.id)?'أُضيفت الأداة إلى المفضلة':'أُزيلت الأداة من المفضلة')}else if(btn.dataset.action==='detail')detail(tool)});
 $('searchInput').addEventListener('input',e=>{state.query=e.target.value.trim().toLocaleLowerCase();state.visible=24;render()});
 $('favoritesButton').addEventListener('click',()=>{state.favorites=!state.favorites;state.visible=24;render()});
 $('freeOnly').addEventListener('change',e=>{state.onlyFree=e.target.checked;state.visible=24;render()});
 $('sortSelect').addEventListener('change',e=>{state.sort=e.target.value;state.visible=24;render()});
 $('loadMore').addEventListener('click',()=>{state.visible+=24;render()});
 $('resetFilters').addEventListener('click',resetFilters);$('emptyReset').addEventListener('click',resetFilters);
 $('accentButton').addEventListener('click',()=>{const colors=['violet','ocean','sunset','emerald'];const next=colors[(colors.indexOf(document.body.dataset.accent)+1)%colors.length];document.body.dataset.accent=next;save('alhayti-accent',next);toast('تم تغيير لون الموقع')});
 $('themeButton').addEventListener('click',()=>{const next=document.body.dataset.theme==='dark'?'light':'dark';document.body.dataset.theme=next;save('alhayti-theme',next);toast(next==='dark'?'تم تفعيل المظهر الداكن':'تم تفعيل المظهر الفاتح')});
 $('menuButton').addEventListener('click',()=>{const menu=$('mobileMenu');menu.hidden=!menu.hidden;$('menuButton').setAttribute('aria-expanded',String(!menu.hidden))});
 $('mobileMenu').addEventListener('click',e=>{if(e.target.closest('a')){$('mobileMenu').hidden=true;$('menuButton').setAttribute('aria-expanded','false')}});
 $('suggestButton').addEventListener('click',openSuggest);
 document.querySelectorAll('[data-utility]').forEach(btn=>btn.addEventListener('click',()=>openUtility(btn.dataset.utility)));
 $('modalRoot').addEventListener('click',e=>{if(e.target.closest('[data-close-modal]'))closeModal()});
 document.addEventListener('keydown',e=>{if(e.key==='Escape'){if(!$('modalRoot').hidden)closeModal();else if(!$('mobileMenu').hidden)$('mobileMenu').hidden=true}else if(e.key==='/'&&!['INPUT','TEXTAREA'].includes(document.activeElement.tagName)&&$('modalRoot').hidden){e.preventDefault();$('searchInput').focus()}});
 $('backToTop').addEventListener('click',()=>window.scrollTo({top:0,behavior:'smooth'}));
 window.addEventListener('scroll',()=>$('backToTop').classList.toggle('visible',window.scrollY>650),{passive:true});
 if('serviceWorker' in navigator && /^https?:$/.test(location.protocol))navigator.serviceWorker.register('sw.js').catch(()=>{});
}
document.addEventListener('DOMContentLoaded',init);
