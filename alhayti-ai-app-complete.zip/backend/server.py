"""ALHAYTI AI — FastAPI service and SQL database.
Run locally: uvicorn server:app --reload
Deployment: uvicorn server:app --host 0.0.0.0 --port $PORT
"""
from __future__ import annotations
import hashlib, hmac, json, os, re, secrets, threading, time
from datetime import datetime, timedelta, timezone
from pathlib import Path
from urllib.parse import urlsplit, quote
from urllib.request import Request as URLRequest, urlopen
from concurrent.futures import ThreadPoolExecutor, as_completed

from argon2 import PasswordHasher
from argon2.exceptions import VerifyMismatchError, VerificationError
from fastapi import FastAPI, Depends, Header, HTTPException, Request, Response, Cookie
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel, Field, field_validator
from sqlalchemy import Boolean, Column, DateTime, ForeignKey, Integer, LargeBinary, String, Text, UniqueConstraint, create_engine, func, select
from sqlalchemy.exc import IntegrityError
from sqlalchemy.orm import DeclarativeBase, sessionmaker, Session

ROOT = Path(__file__).resolve().parent
DB_URL = os.getenv('DATABASE_URL', f"sqlite:///{ROOT/'data'/'alhayti.sqlite3'}")
if DB_URL.startswith('postgres://'):
    DB_URL = 'postgresql://' + DB_URL[len('postgres://'):]
if DB_URL.startswith('postgresql://'):
    # psycopg3 is installed by requirements.txt
    DB_URL = 'postgresql+psycopg://' + DB_URL[len('postgresql://'):]
connect_args = {'check_same_thread': False, 'timeout': 30} if DB_URL.startswith('sqlite:') else {}
engine = create_engine(DB_URL, connect_args=connect_args, pool_pre_ping=True)
SessionLocal = sessionmaker(bind=engine, autoflush=False, expire_on_commit=False)
ph = PasswordHasher(time_cost=2, memory_cost=32768, parallelism=2)
PUBLIC_REGISTER = os.getenv('ENABLE_REGISTRATION', 'true').lower() == 'true'
SECURE_COOKIE = os.getenv('APP_ENV','development').lower() == 'production'
BOOTSTRAP_EMAIL = os.getenv('ADMIN_EMAIL', '').strip().lower()
BOOTSTRAP_PASSWORD = os.getenv('ADMIN_PASSWORD','')

class Base(DeclarativeBase): pass
class Tool(Base):
    __tablename__ = 'tools'
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    category = Column(String(40), nullable=False, index=True)
    url = Column(String(500), nullable=False)
    description = Column(Text, nullable=False)
    plan = Column(String(1), default='v')
    source = Column(String(80), default='manual')
    logo_bytes = Column(LargeBinary, nullable=True)
    created_at = Column(DateTime(timezone=True), default=lambda:datetime.now(timezone.utc))
    __table_args__ = (UniqueConstraint('name', name='uq_tool_name'),)
class User(Base):
    __tablename__ = 'users'
    id = Column(Integer, primary_key=True)
    name = Column(String(80), nullable=False)
    email = Column(String(254), unique=True, nullable=False, index=True)
    password_hash = Column(String(500), nullable=False)
    role = Column(String(10), default='user', nullable=False)
    active = Column(Boolean, default=True)
    created_at = Column(DateTime(timezone=True), default=lambda:datetime.now(timezone.utc))
class LoginSession(Base):
    __tablename__ = 'login_sessions'
    id = Column(Integer, primary_key=True)
    token_hash = Column(String(64), unique=True, nullable=False, index=True)
    csrf_hash = Column(String(64), nullable=False)
    user_id = Column(Integer, ForeignKey('users.id', ondelete='CASCADE'), nullable=False)
    expires_at = Column(DateTime(timezone=True), nullable=False)
class Favorite(Base):
    __tablename__ = 'favorites'
    user_id = Column(Integer, ForeignKey('users.id',ondelete='CASCADE'), primary_key=True)
    tool_id = Column(Integer, ForeignKey('tools.id',ondelete='CASCADE'), primary_key=True)

CATEGORIES = {'chat','search','image','photo','video','avatar','audio','code','build','writing','design','autom','education','translate','threeD','marketing','data','security'}
CATEGORY_MAP = {
 'chatbots':'chat','chatbot':'chat','ai agents':'autom','ai agent':'autom',
 'ai assistant':'chat','virtual assistant':'chat','customer support':'autom',
 'search engines':'search','research':'search','academic':'search','market research':'search',
 'image generation':'image','ai image generator':'image','image generator':'image',
 'image editing':'photo','background remover':'photo','photo editing':'photo',
 'video generator':'video','video editing':'video','video':'video','talking avatar generator':'avatar',
 'avatar':'avatar','music generation':'audio','text to speech':'audio','speech to text':'audio',
 'audio editing':'audio','podcast':'audio','audio':'audio',
 'coding':'code','devtools':'code','developer tools':'code','code assistants':'code',
 'website builders':'build','website builder':'build','app builders':'build',
 'writing':'writing','copywriting':'writing','email assistants':'writing','email':'writing',
 'graphic design':'design','design':'design','presentations':'design',
 'productivity':'autom','automation':'autom','workflow automation':'autom','meeting assistants':'autom',
 'education':'education','learning':'education','translator':'translate','translation':'translate',
 '3d':'threeD','3d modeling':'threeD','marketing':'marketing','seo':'marketing',
 'lead generation':'marketing','sales tools':'marketing','social media tools':'marketing','crm':'marketing',
 'data':'data','data analytics':'data','database tools':'data','analytics':'data',
 'security':'security','cybersecurity':'security'
}

def db():
    with SessionLocal() as s: yield s

def public_tool(row):
    return {'id':row.id, 'name':row.name, 'category':row.category,'url':row.url,
            'description':row.description,'plan':row.plan,'source':row.source,'has_cached_logo':row.logo_bytes is not None}

def clean_url(url):
    url = url.strip()
    try:
        p = urlsplit(url)
        if p.scheme != 'https' or not p.hostname or p.username or p.password: raise ValueError()
        if len(p.hostname) > 250 or p.hostname in ('localhost','127.0.0.1'): raise ValueError()
        return url
    except Exception: raise ValueError('رابط https صالح مطلوب')

class ToolPayload(BaseModel):
    name: str = Field(min_length=2,max_length=120)
    category: str
    url: str = Field(max_length=500)
    description: str = Field(min_length=5,max_length=1500)
    plan: str = 'v'
    @field_validator('category')
    @classmethod
    def category_valid(cls,v):
        if v not in CATEGORIES: raise ValueError('تصنيف غير معروف')
        return v
    @field_validator('plan')
    @classmethod
    def plan_valid(cls,v):
        if v not in {'f','x','p','v'}: raise ValueError('خطة غير صحيحة')
        return v
    @field_validator('url')
    @classmethod
    def url_valid(cls,v): return clean_url(v)

class Registration(BaseModel):
    name: str = Field(min_length=2,max_length=80)
    email: str = Field(min_length=5,max_length=254)
    password: str = Field(min_length=12,max_length=128)
class Credentials(BaseModel):
    email: str
    password: str
class RoleUpdate(BaseModel):
    role: str

app = FastAPI(title='ALHAYTI AI API', docs_url=None, redoc_url=None)
app.mount('/static', StaticFiles(directory=ROOT/'static'), name='static')

@app.middleware('http')
async def origin_guard(request: Request, call_next):
    if request.method in {'POST','PUT','PATCH','DELETE'}:
        origin = request.headers.get('origin')
        if origin:
            from urllib.parse import urlsplit
            host = request.headers.get('host','')
            parsed = urlsplit(origin)
            if parsed.netloc.lower() != host.lower():
                return JSONResponse({'detail':'Origin not allowed'},status_code=403)
    return await call_next(request)

@app.on_event('startup')
def init_db():
    Base.metadata.create_all(engine)
    with SessionLocal() as s:
        if not s.scalar(select(func.count(Tool.id))):
            seed = json.loads((ROOT/'data'/'seed-tools.json').read_text())
            s.add_all([Tool(**t) for t in seed]);s.commit()
        if BOOTSTRAP_EMAIL and BOOTSTRAP_PASSWORD:
            if len(BOOTSTRAP_PASSWORD) < 12: raise RuntimeError('ADMIN_PASSWORD must contain 12+ characters')
            admin = s.scalar(select(User).where(User.email==BOOTSTRAP_EMAIL))
            if not admin:
                s.add(User(name='المهندس إسماعيل الحايطي',email=BOOTSTRAP_EMAIL,
                           password_hash=ph.hash(BOOTSTRAP_PASSWORD),role='admin'))
                s.commit()
    if os.getenv('AUTO_IMPORT','false').lower() == 'true':
        # Optional one-time catalogue import, network access required.
        with SessionLocal() as s:
            if s.scalar(select(func.count(Tool.id))) < 800:
                threading.Thread(target=import_to_800, daemon=True).start()

@app.get('/')
def home(): return FileResponse(ROOT/'static'/'index.html')
@app.get('/admin')
def admin(): return FileResponse(ROOT/'static'/'admin.html')
@app.get('/health')
def health(): return {'ok':True}
@app.get('/api/tools')
def tools_list(s:Session=Depends(db)):
    return {'tools':[public_tool(t) for t in s.scalars(select(Tool).order_by(Tool.id)).all()]}
@app.get('/api/stats')
def stats(s:Session=Depends(db)):
    return {'tools':s.scalar(select(func.count(Tool.id))), 'users':s.scalar(select(func.count(User.id)))}

def hash_val(v): return hashlib.sha256(v.encode()).hexdigest()

def session_user(raw_token:str|None, s:Session):
    if not raw_token: return None,None
    login = s.scalar(select(LoginSession).where(LoginSession.token_hash==hash_val(raw_token)))
    if not login: return None,None
    now=datetime.now(timezone.utc)
    if login.expires_at.replace(tzinfo=timezone.utc) <= now: return None,None
    user=s.get(User,login.user_id)
    if not user or not user.active: return None,None
    return user,login

def require_user(request:Request,s:Session=Depends(db)):
    user,login=session_user(request.cookies.get('alhayti_session'),s)
    if not user: raise HTTPException(401,'يرجى تسجيل الدخول')
    if request.method not in {'GET','HEAD','OPTIONS'}:
        csrf = request.headers.get('x-csrf-token','')
        if not csrf or not hmac.compare_digest(hash_val(csrf),login.csrf_hash): raise HTTPException(403,'رمز حماية الطلب غير صالح')
    return user

def require_admin(request:Request,s:Session=Depends(db)):
    user=require_user(request,s)
    if user.role!='admin': raise HTTPException(403,'للمدير فقط')
    return user

_login_attempts={}
def throttle_login(request:Request):
    ip = request.client.host if request.client else 'unknown'
    now=time.monotonic()
    times=[t for t in _login_attempts.get(ip,[]) if now-t < 600]
    if len(times)>=15: raise HTTPException(429,'محاولات كثيرة، حاول لاحقاً')
    times.append(now)
    _login_attempts[ip]=times

@app.post('/api/auth/register')
def register(payload: Registration, request:Request, s:Session=Depends(db)):
    if not PUBLIC_REGISTER: raise HTTPException(403,'التسجيل مغلق')
    throttle_login(request)
    email=payload.email.strip().lower()
    if not re.fullmatch(r'[^\s@]+@[^\s@]+\.[^\s@]+',email): raise HTTPException(422,'البريد الإلكتروني غير صالح')
    if s.scalar(select(User).where(User.email==email)): raise HTTPException(409,'البريد مسجل مسبقًا')
    s.add(User(name=payload.name.strip(),email=email,password_hash=ph.hash(payload.password),role='user'))
    s.commit();return {'ok':True}

@app.post('/api/auth/login')
def login(payload:Credentials,request:Request,response:Response,s:Session=Depends(db)):
    throttle_login(request)
    user=s.scalar(select(User).where(User.email==payload.email.strip().lower()))
    valid=False
    if user and user.active:
        try: valid=ph.verify(user.password_hash,payload.password)
        except (VerifyMismatchError,VerificationError):pass
    if not valid: raise HTTPException(401,'البريد أو كلمة المرور غير صحيحة')
    raw=secrets.token_urlsafe(32);csrf=secrets.token_urlsafe(32)
    s.add(LoginSession(token_hash=hash_val(raw),csrf_hash=hash_val(csrf),user_id=user.id,
                       expires_at=datetime.now(timezone.utc)+timedelta(days=7)))
    s.commit()
    response.set_cookie('alhayti_session',raw,secure=SECURE_COOKIE,httponly=True,samesite='lax',max_age=604800,path='/')
    return {'ok':True,'csrf':csrf,'user':{'id':user.id,'name':user.name,'role':user.role,'email':user.email}}

@app.get('/api/auth/me')
def me(request:Request,s:Session=Depends(db)):
    user,login=session_user(request.cookies.get('alhayti_session'),s)
    if not user: return {'user':None}
    # CSRF value cannot be recovered from its hash. A fresh token is issued per authenticated GET and stored as hash.
    csrf=secrets.token_urlsafe(32);login.csrf_hash=hash_val(csrf);s.commit()
    return {'user':{'id':user.id,'name':user.name,'role':user.role,'email':user.email},'csrf':csrf,
            'favorites':[f.tool_id for f in s.scalars(select(Favorite).where(Favorite.user_id==user.id)).all()]}

@app.post('/api/auth/logout')
def logout(request:Request,response:Response,user:User=Depends(require_user),s:Session=Depends(db)):
    raw=request.cookies.get('alhayti_session','')
    token=s.scalar(select(LoginSession).where(LoginSession.token_hash==hash_val(raw)))
    if token:s.delete(token);s.commit()
    response.delete_cookie('alhayti_session',path='/');return {'ok':True}

@app.post('/api/favorites/{tool_id}')
def add_favorite(tool_id:int,request:Request,user:User=Depends(require_user),s:Session=Depends(db)):
    if not s.get(Tool,tool_id): raise HTTPException(404)
    if not s.get(Favorite,(user.id,tool_id)):
        s.add(Favorite(user_id=user.id,tool_id=tool_id));s.commit()
    return {'ok':True}
@app.delete('/api/favorites/{tool_id}')
def delete_favorite(tool_id:int,request:Request,user:User=Depends(require_user),s:Session=Depends(db)):
    x=s.get(Favorite,(user.id,tool_id))
    if x:s.delete(x);s.commit()
    return {'ok':True}

@app.get('/api/admin/users')
def users_list(request:Request,user:User=Depends(require_admin),s:Session=Depends(db)):
    return [{'id':u.id,'name':u.name,'email':u.email,'role':u.role,'active':u.active} for u in s.scalars(select(User).order_by(User.id.desc())).all()]
@app.patch('/api/admin/users/{user_id}')
def user_role(user_id:int, payload:RoleUpdate,request:Request,admin:User=Depends(require_admin),s:Session=Depends(db)):
    if payload.role not in {'user','admin'}:raise HTTPException(400,'دور غير صحيح')
    if user_id==admin.id and payload.role!='admin':raise HTTPException(400,'لا يمكن إزالة صلاحيتك')
    obj=s.get(User,user_id)
    if not obj:raise HTTPException(404)
    obj.role=payload.role;s.commit();return {'ok':True}
@app.post('/api/admin/tools')
def create_tool(data:ToolPayload,request:Request,user:User=Depends(require_admin),s:Session=Depends(db)):
    if s.scalar(select(Tool).where(func.lower(Tool.name)==data.name.strip().lower())):raise HTTPException(409,'اسم الأداة موجود')
    obj=Tool(**data.model_dump(),source='admin');s.add(obj);s.commit();return public_tool(obj)
@app.put('/api/admin/tools/{tool_id}')
def edit_tool(tool_id:int,data:ToolPayload,request:Request,user:User=Depends(require_admin),s:Session=Depends(db)):
    obj=s.get(Tool,tool_id)
    if not obj:raise HTTPException(404,'الأداة غير موجودة')
    if obj.url!=data.url:obj.logo_bytes=None
    for k,v in data.model_dump().items():setattr(obj,k,v)
    s.commit();return public_tool(obj)
@app.delete('/api/admin/tools/{tool_id}')
def remove_tool(tool_id:int,request:Request,user:User=Depends(require_admin),s:Session=Depends(db)):
    obj=s.get(Tool,tool_id)
    if not obj:raise HTTPException(404)
    for fav in s.scalars(select(Favorite).where(Favorite.tool_id==tool_id)).all():s.delete(fav)
    s.delete(obj);s.commit();return {'ok':True}

# Public directory: https://bestaihub.cc/about/ - index.json is declared open data.
def category_from_source(value):
    v=(value or '').strip().lower()
    if v in CATEGORY_MAP:return CATEGORY_MAP[v]
    for part,cat in [('image','image'),('photo','photo'),('video','video'),('music','audio'),
                     ('audio','audio'),('speech','audio'),('avatar','avatar'),('design','design'),
                     ('code','code'),('developer','code'),('website','build'),('translate','translate'),
                     ('marketing','marketing'),('seo','marketing'),('sales','marketing'),('data','data'),
                     ('educat','education'),('learning','education'),('security','security'),
                     ('research','search'),('search','search'),('writing','writing'),('document','writing'),
                     ('productivity','autom'),('agent','autom')]:
        if part in v:return cat
    return 'autom'

def import_to_800():
    # Select exactly as many nonduplicate names as necessary; do not invent entries.
    req=URLRequest('https://bestaihub.cc/index.json',headers={'User-Agent':'ALHAYTI-AI-directory-import/1.0'})
    with urlopen(req,timeout=35) as resp:
        raw=resp.read(12_000_000)
    dataset=json.loads(raw)
    with SessionLocal() as s:
        count=s.scalar(select(func.count(Tool.id)))
        current={r.name.strip().casefold() for r in s.scalars(select(Tool)).all()}
        # Round-robin through categories instead of taking only alphabetically early entries.
        buckets={}
        candidates=[]
        for item in dataset:
            if item.get('type')!='tool' or item.get('dead'):continue
            name=(item.get('name') or '').strip()
            url=(item.get('website') or '').strip()
            desc=(item.get('description') or '').strip()
            try:url=clean_url(url)
            except ValueError:continue
            if not 2<=len(name)<=120 or not 5<=len(desc)<=1500 or name.casefold() in current:continue
            cat=category_from_source(item.get('category'))
            buckets.setdefault(cat,[]).append((name,url,desc,cat,item.get('price')))
        # First diversity pass, then round-robin until target is reached.
        ordered=[]
        while buckets:
            for cat in list(buckets):
                if buckets[cat]: ordered.append(buckets[cat].pop(0))
                if not buckets[cat]:del buckets[cat]
        added=0
        for name,url,desc,cat,price in ordered:
            if count+added>=800:break
            if name.casefold() in current:continue
            plan={'Free':'x','Freemium':'f','Paid':'p'}.get(price,'v')
            s.add(Tool(name=name,url=url,category=cat,description=desc,plan=plan,source='bestaihub.cc'))
            current.add(name.casefold());added+=1
        s.commit()
        return {'total':count+added,'added':added,'target':800,'source':'https://bestaihub.cc/index.json'}

@app.post('/api/admin/import-to-800')
def admin_import(request:Request,user:User=Depends(require_admin)):
    try:return import_to_800()
    except Exception as exc:
        raise HTTPException(503,'تعذّر تحميل القائمة الخارجية؛ تحقق من اتصال الخادم بالمصدر وأعد المحاولة') from exc

# Cache branded favicons once as database BLOBs so they persist across restarts.
def logo_fetch(tool_id):
    with SessionLocal() as s:
        row=s.get(Tool,tool_id)
        if not row:return None
        if row.logo_bytes:return row.logo_bytes
        hostname=urlsplit(row.url).hostname or ''
        if not hostname:return None
        req=URLRequest('https://www.google.com/s2/favicons?sz=128&domain_url='+quote('https://'+hostname,safe=''),
                       headers={'User-Agent':'Mozilla/5.0'})
        try:
            with urlopen(req,timeout=9) as response:
                if 'image/' not in response.headers.get('Content-Type',''):return None
                logo=response.read(40_000)
            from io import BytesIO
            from PIL import Image
            im=Image.open(BytesIO(logo));im.verify()
            if len(logo)<70:return None
            im=Image.open(BytesIO(logo)).convert('RGBA')
            buffer=BytesIO();im.save(buffer,format='PNG');logo=buffer.getvalue()
            row.logo_bytes=logo;s.commit();return logo
        except Exception:return None

@app.get('/api/logos/{tool_id}')
def branded_logo(tool_id:int,s:Session=Depends(db)):
    row=s.get(Tool,tool_id)
    if not row:raise HTTPException(404)
    if row.logo_bytes:return Response(row.logo_bytes,media_type='image/png',headers={'Cache-Control':'public,max-age=86400'})
    # Do not block rendering on an external request. Use external provider until cache operation is run.
    host=urlsplit(row.url).hostname or ''
    return RedirectResponse('https://www.google.com/s2/favicons?sz=128&domain_url='+quote('https://'+host,safe=''),status_code=302)

@app.post('/api/admin/cache-logos')
def cache_logos(request:Request,user:User=Depends(require_admin),s:Session=Depends(db)):
    missing=[t.id for t in s.scalars(select(Tool).where(Tool.logo_bytes.is_(None))).all()]
    # Cap the call, leaving a useful actionable batch to avoid request timeouts.
    count=0
    with ThreadPoolExecutor(max_workers=8) as pool:
        futures=[pool.submit(logo_fetch,id) for id in missing[:48]]
        for future in as_completed(futures):
            if future.result() is not None:count+=1
    return {'cached':count,'processed':min(len(missing),48),'remaining_approx':max(0,len(missing)-count)}
