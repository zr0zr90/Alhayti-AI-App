package com.alhayti.ai;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.net.Uri;
import android.os.Bundle;
import android.os.Message;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.PopupMenu;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.webkit.WebViewAssetLoader;

import java.util.Locale;

/**
 * الحايطي AI native Android shell.
 * Offline mode bundles the 155-tool catalogue, while Online mode loads a user-specified HTTPS backend.
 * No JavaScript interface is exposed to remote pages. External tool links open in a browser.
 */
public class MainActivity extends Activity {
    private static final String LOCAL_URL = "https://appassets.androidplatform.net/assets/www/index.html";
    private static final String PREFS = "alhayti_preferences";
    private static final String URL_KEY = "online_url";
    private static final String MODE_KEY = "online_mode";

    private WebView browser;
    private ProgressBar progress;
    private TextView modeLabel;
    private SharedPreferences preferences;
    private WebViewAssetLoader assetLoader;
    private boolean errorShown = false;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        preferences = getSharedPreferences(PREFS, MODE_PRIVATE);

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.rgb(9,15,30));
        root.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setPadding(dp(14),dp(7),dp(10),dp(7));
        bar.setBackgroundColor(Color.rgb(16,26,45));

        TextView title = new TextView(this);
        title.setText("✦ الحايطي AI");
        title.setTextColor(Color.WHITE);
        title.setTextSize(17);
        title.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        bar.addView(title, new LinearLayout.LayoutParams(0,dp(48),1f));
        title.setGravity(Gravity.CENTER_VERTICAL);

        modeLabel = new TextView(this);
        modeLabel.setTextColor(Color.rgb(162,196,224));
        modeLabel.setTextSize(10);
        modeLabel.setGravity(Gravity.CENTER);
        bar.addView(modeLabel,new LinearLayout.LayoutParams(dp(69),dp(48)));

        TextView menu = new TextView(this);
        menu.setText("⋮");
        menu.setTextSize(28);
        menu.setTextColor(Color.WHITE);
        menu.setGravity(Gravity.CENTER);
        menu.setContentDescription("إعدادات التطبيق");
        menu.setOnClickListener(this::showMenu);
        bar.addView(menu,new LinearLayout.LayoutParams(dp(42),dp(48)));

        root.addView(bar,new LinearLayout.LayoutParams(-1,dp(62)));
        progress = new ProgressBar(this,null,android.R.attr.progressBarStyleHorizontal);
        progress.setMax(100);
        progress.setProgressTintList(android.content.res.ColorStateList.valueOf(Color.rgb(144,103,255)));
        progress.setVisibility(View.GONE);
        root.addView(progress,new LinearLayout.LayoutParams(-1,dp(3)));

        browser = new WebView(this);
        browser.setBackgroundColor(Color.rgb(9,15,30));
        browser.setOverScrollMode(View.OVER_SCROLL_NEVER);
        root.addView(browser,new LinearLayout.LayoutParams(-1,0,1f));
        setContentView(root);

        assetLoader = new WebViewAssetLoader.Builder()
                .addPathHandler("/assets/",new WebViewAssetLoader.AssetsPathHandler(this))
                .build();

        WebSettings settings = browser.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setAllowFileAccess(false);
        settings.setAllowContentAccess(false);
        settings.setAllowFileAccessFromFileURLs(false);
        settings.setAllowUniversalAccessFromFileURLs(false);
        settings.setJavaScriptCanOpenWindowsAutomatically(true);
        settings.setSupportMultipleWindows(true);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setSafeBrowsingEnabled(true);
        settings.setBuiltInZoomControls(false);
        settings.setDisplayZoomControls(false);
        CookieManager.getInstance().setAcceptCookie(true);

        browser.setWebViewClient(new WebViewClient() {
            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                Uri uri = request.getUrl();
                return handleNavigation(uri);
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && isOnlineMode() && !errorShown) {
                    errorShown = true;
                    runOnUiThread(() -> new AlertDialog.Builder(MainActivity.this)
                            .setTitle("تعذر الاتصال بالموقع")
                            .setMessage("لا يمكن فتح خادم الحايطي AI الآن. يمكنك متابعة استخدام دليل الأدوات المحفوظ داخل التطبيق.")
                            .setPositiveButton("الدخول دون إنترنت",(d,w)->switchToOffline())
                            .setNegativeButton("إعادة المحاولة",(d,w)->{errorShown=false;browser.reload();})
                            .show());
                }
            }
        });

        browser.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onProgressChanged(WebView view, int newProgress) {
                progress.setProgress(newProgress);
                progress.setVisibility(newProgress>=100?View.GONE:View.VISIBLE);
            }
            @Override
            public boolean onCreateWindow(WebView view, boolean isDialog, boolean isUserGesture, Message resultMsg) {
                if (!isUserGesture || resultMsg==null) return false;
                WebView popup=new WebView(MainActivity.this);
                popup.setWebViewClient(new WebViewClient() {
                    @Override public boolean shouldOverrideUrlLoading(WebView w, WebResourceRequest request) {
                        openExternal(request.getUrl());
                        w.post(w::destroy);
                        return true;
                    }
                });
                WebView.WebViewTransport transport=(WebView.WebViewTransport)resultMsg.obj;
                transport.setWebView(popup);
                resultMsg.sendToTarget();
                return true;
            }
        });

        loadHome();
    }

    private int dp(float value){return (int)(value*getResources().getDisplayMetrics().density+0.5f);}

    private boolean isOnlineMode(){return preferences.getBoolean(MODE_KEY,false) && !preferences.getString(URL_KEY,"").isEmpty();}

    private void loadHome() {
        errorShown = false;
        modeLabel.setText(isOnlineMode()?"🌐 متصل":"◈ محلي");
        browser.loadUrl(isOnlineMode()?preferences.getString(URL_KEY,LOCAL_URL):LOCAL_URL);
    }

    private boolean handleNavigation(Uri uri) {
        String scheme = uri.getScheme();
        if (scheme==null) return true;
        if (scheme.equals("https") && "appassets.androidplatform.net".equalsIgnoreCase(uri.getHost())) return false;
        if (isOnlineMode() && scheme.equals("https")) {
            Uri host=Uri.parse(preferences.getString(URL_KEY,""));
            if (uri.getHost()!=null && uri.getHost().equalsIgnoreCase(host.getHost()) && uri.getPort()==host.getPort()) return false;
        }
        if (scheme.equals("https") || scheme.equals("http") || scheme.equals("tel") || scheme.equals("mailto") || scheme.equals("market") || scheme.equals("intent")) {
            openExternal(uri); return true;
        }
        return true;
    }

    private void openExternal(Uri uri) {
        try {
            if ("intent".equalsIgnoreCase(uri.getScheme())) {
                Intent intent=Intent.parseUri(uri.toString(),Intent.URI_INTENT_SCHEME);
                if (intent.getComponent()!=null) intent.setComponent(null);
                intent.setSelector(null);
                startActivity(intent);
            } else {
                Intent intent=new Intent(Intent.ACTION_VIEW,uri);
                intent.addCategory(Intent.CATEGORY_BROWSABLE);
                startActivity(intent);
            }
        } catch (Exception ex) {
            Toast.makeText(this,"لا يوجد تطبيق لفتح الرابط",Toast.LENGTH_SHORT).show();
        }
    }

    private void showMenu(View anchor) {
        PopupMenu menu=new PopupMenu(this,anchor);
        menu.getMenu().add(0,1,1,"دليل الأدوات دون إنترنت");
        menu.getMenu().add(0,2,2,"ربط رابط موقع الحايطي AI");
        menu.getMenu().add(0,3,3,"تحديث الصفحة");
        menu.getMenu().add(0,4,4,"عن التطبيق");
        menu.setOnMenuItemClickListener(item->{
            switch(item.getItemId()) {
                case 1:switchToOffline();return true;
                case 2:showUrlDialog();return true;
                case 3:browser.reload();return true;
                case 4:showAbout();return true;
                default:return false;
            }
        });
        menu.show();
    }

    private void switchToOffline(){preferences.edit().putBoolean(MODE_KEY,false).apply();loadHome();}

    private void showUrlDialog() {
        EditText input=new EditText(this);
        input.setSingleLine(true);
        input.setTextDirection(View.TEXT_DIRECTION_LTR);
        input.setText(preferences.getString(URL_KEY,""));
        input.setHint("https://your-site.onrender.com");
        LinearLayout box=new LinearLayout(this);
        box.setPadding(dp(24),dp(6),dp(24),0);
        box.addView(input,new LinearLayout.LayoutParams(-1,-2));
        new AlertDialog.Builder(this).setTitle("ربط الموقع المنشور")
                .setMessage("بعد نشر موقعك على خادم آمن HTTPS، أدخل رابطه الرئيسي هنا لعرض الحسابات ولوحة الإدارة والبيانات المحدثة. لا تدخل كلمة المرور هنا.")
                .setView(box)
                .setPositiveButton("حفظ وفتح",(dialog,which)->{
                    String url=input.getText().toString().trim();
                    Uri uri=Uri.parse(url);
                    boolean valid=uri.getScheme()!=null&&uri.getScheme().equalsIgnoreCase("https")&&uri.getHost()!=null
                            && uri.getUserInfo()==null&&uri.getPort()==-1&&url.length()<300;
                    if(!valid){Toast.makeText(this,"أدخل رابط HTTPS صحيحًا من دون منفذ أو بيانات دخول",Toast.LENGTH_LONG).show();return;}
                    String base="https://"+uri.getHost().toLowerCase(Locale.ROOT);
                    preferences.edit().putString(URL_KEY,base).putBoolean(MODE_KEY,true).apply();
                    loadHome();
                })
                .setNegativeButton("إلغاء",null).show();
    }

    private void showAbout(){new AlertDialog.Builder(this)
            .setTitle("الحايطي AI | الإصدار 1.0")
            .setMessage("دليل أدوات الذكاء الاصطناعي\n\nالنسخة المحلية: 155 أداة يمكن البحث فيها وتصفحها.\nالنسخة المتصلة: تستخدم موقعك المنشور، مع قاعدة بيانات المستخدمين ولوحة الإدارة.\n\nتطوير المهندس إسماعيل يحيى هزاع الحايطي\nالقسم: أمن سيبراني وشبكات\n+967779922816")
            .setPositiveButton("حسنًا",null).show();}

    @Override
    public void onBackPressed(){
        if(browser!=null && browser.canGoBack()) browser.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onDestroy(){
        if(browser!=null){
            ((ViewGroup)browser.getParent()).removeView(browser);
            browser.destroy();browser=null;
        }
        super.onDestroy();
    }
}
